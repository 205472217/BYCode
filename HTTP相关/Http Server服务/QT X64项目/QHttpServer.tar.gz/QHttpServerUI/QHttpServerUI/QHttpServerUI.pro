QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

# 获取Qt版本号
QT_VERSION = $$QT_VERSION
greaterThan(QT_VERSION, 6.6.3): QMAKE_CXXFLAGS += -Wno-unused-parameter

#定义构建目录
build_dir = $$PWD/../bin
#配置构建目录
DESTDIR = $$build_dir/bin
OBJECTS_DIR = $$build_dir/$$TARGET/obj
MOC_DIR = $$build_dir/$$TARGET/moc
RCC_DIR = $$build_dir/$$TARGET/rcc



#添加头文件目录
INCLUDEPATH +=$$PWD/../public
INCLUDEPATH +=$$PWD/../public/openssl
INCLUDEPATH +=$$PWD/../public/libevent

#only for unix
QMAKE_LFLAGS += -Wl,-rpath,$$DESTDIR

LIBS += -L$$build_dir/bin -lcrypto
LIBS += -L$$build_dir/bin -lssl
LIBS += -L$$build_dir/bin -levent
LIBS += -L$$build_dir/bin -levent_core
LIBS += -L$$build_dir/bin -levent_extra
LIBS += -L$$build_dir/bin -levent_openssl
LIBS += -L$$build_dir/bin -levent_pthreads





SOURCES += \
    ../public/HttpServerThreadPool.cpp \
    main.cpp \
    QHttpServerUI.cpp

HEADERS += \
    ../public/HttpServerThreadPool.h \
    QHttpServerUI.h

FORMS += \
    QHttpServerUI.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
